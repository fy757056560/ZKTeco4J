package ps.purelogic.zkteco4j.terminal;

import ps.purelogic.zkteco4j.command.events.EventCode;
import ps.purelogic.zkteco4j.commands.ZKCommandReply;
import ps.purelogic.zkteco4j.commands.GetTimeReply;
import ps.purelogic.zkteco4j.utils.HexUtils;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class Test {

    public static void main(String[] args) throws Exception {
        Properties prop = new Properties();
        try (FileInputStream fis = new FileInputStream("/home/ubuntu/upload/ZKTeco4J-main/config.properties")) {
            prop.load(fis);
        } catch (IOException ex) {
            System.err.println("无法加载配置文件: " + ex.getMessage());
            return;
        }

        String ip = prop.getProperty("zk.ip");
        int port = Integer.parseInt(prop.getProperty("zk.port"));

        if (ip == null || ip.isEmpty()) {
            System.err.println("配置文件中缺少zk.ip参数。");
            return;
        }

        ZKTerminal terminal = new ZKTerminal(ip, port);

        try {
            System.out.println("尝试连接考勤机 " + ip + ":" + port + "...");
            ZKCommandReply connectReply = terminal.connect();
            System.out.println("连接结果: " + connectReply.getCode());

            if (connectReply.getCode().isOk()) {
                System.out.println("连接成功！会话ID: " + connectReply.getSessionId());

                // 尝试认证，如果考勤机有密码，请在这里修改commKey
                // int commKey = 0; // 默认密码为0，如果您的考勤机有密码，请修改
                // ZKCommandReply authReply = terminal.connectAuth(commKey);
                // System.out.println("认证结果: " + authReply.getCode());

                // 尝试获取设备时间
                System.out.println("尝试获取设备时间...");
                GetTimeReply timeReply = terminal.getDeviceTime();
                if (timeReply.getCode().isOk()) {
                    System.out.println("设备时间: " + timeReply.getDeviceTime());
                } else {
                    System.out.println("获取设备时间失败: " + timeReply.getCode());
                }

                // 启用设备，使其可以正常工作
                System.out.println("尝试启用设备...");
                ZKCommandReply enableReply = terminal.enableDevice();
                System.out.println("启用设备结果: " + enableReply.getCode());

                // 启用实时事件（可选，根据需要开启）
                // System.out.println("尝试启用实时事件...");
                // ZKCommandReply eventReply = terminal.enableRealtime(EventCode.EF_FINGER);
                // System.out.println("启用实时事件结果: " + eventReply.getCode());

                // 读取考勤记录（如果需要）
                // System.out.println("尝试读取考勤记录...");
                // ZKCommandReply attendanceReply = terminal.getAttendanceRecords();
                // System.out.println("读取考勤记录结果: " + attendanceReply.getCode());

            } else {
                System.out.println("连接失败: " + connectReply.getCode());
            }

        } catch (Exception e) {
            System.err.println("连接或操作过程中发生错误: " + e.getMessage());
            e.printStackTrace();
        } finally {
            // 确保断开连接
            if (terminal != null) {
                try {
                    System.out.println("断开连接...");
                    terminal.disconnect();
                    System.out.println("连接已断开。");
                } catch (IOException e) {
                    System.err.println("断开连接时发生错误: " + e.getMessage());
                }
            }
        }
    }
}


