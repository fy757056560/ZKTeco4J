# 中控考勤机Java库分析报告

**作者：** Manus AI  
**日期：** 2025年7月23日  
**版本：** 1.0

## 摘要

本报告深入分析了两个用于连接中控（ZKTeco）考勤机的Java库：ZKTeco4J-main和ZKEMJavaPort-master。通过对代码结构、功能特性、实现方式和使用场景的详细分析，为开发者提供了选择和使用这些库的全面指导。报告包含了详细的类和方法注释、连接测试方案以及参数配置指导，帮助开发者快速集成考勤机功能到Java应用程序中。

## 1. 引言

中控科技（ZKTeco）是全球领先的生物识别和安防解决方案提供商，其考勤机产品广泛应用于企业、学校、政府机构等各种场所。为了方便开发者集成考勤机功能，社区开发了多个Java库来简化与考勤机的通信过程。

本报告分析的两个库分别代表了不同的技术路径：ZKTeco4J-main采用纯Java实现的UDP通信协议，而ZKEMJavaPort-master则基于COM4J技术调用官方的zkemkeeper.dll动态链接库。这两种方法各有优势，适用于不同的应用场景和技术环境。

通过深入分析这两个库的架构设计、功能特性、性能表现和使用复杂度，开发者可以根据具体需求选择最适合的解决方案。同时，本报告还提供了详细的使用指导和最佳实践，帮助开发者快速上手并避免常见的集成问题。

## 2. 库概述与架构分析

### 2.1 ZKTeco4J-main库架构

ZKTeco4J-main是一个纯Java实现的考勤机通信库，采用UDP协议直接与考勤机进行底层通信。该库的设计理念是提供一个轻量级、跨平台的解决方案，不依赖任何本地动态链接库。

#### 2.1.1 核心架构组件

该库的核心架构由以下几个主要组件构成：

**ZKTerminal类**是整个库的核心通信组件，负责管理与考勤机的UDP连接。它封装了所有底层的网络通信细节，包括数据包的构造、发送、接收和解析。该类采用了会话管理机制，通过sessionId和replyNo来维护通信状态，确保数据传输的可靠性和一致性。

**ZKCommand类**负责构造符合考勤机协议的命令数据包。它定义了标准的数据包格式，包括包头、命令代码、会话信息、校验和以及有效载荷。该类使用小端字节序（Little Endian）来确保与考勤机硬件的兼容性，并实现了完整的校验和算法来保证数据传输的完整性。

**CommandCode枚举**定义了所有支持的考勤机命令，包括连接管理、设备控制、数据读取、用户管理等各个方面。每个命令都有对应的数字代码，这些代码严格遵循ZKTeco的官方协议规范。

**SecurityUtils工具类**提供了安全相关的功能，包括认证密钥生成和校验和计算。它实现了考勤机的安全认证机制，确保只有授权的应用程序才能访问设备。

#### 2.1.2 通信协议实现

ZKTeco4J-main实现了完整的ZKTeco UDP通信协议栈。该协议基于请求-响应模式，每个操作都需要发送特定格式的命令包并等待设备响应。协议包含以下关键特性：

数据包格式采用固定的包头结构，包含魔数、长度信息、命令代码、会话标识和校验和。这种设计确保了数据传输的可靠性和错误检测能力。

会话管理机制通过sessionId来标识每个连接会话，通过replyNo来跟踪命令序列。这种机制防止了命令重复执行和响应混乱的问题。

错误处理和重试机制能够自动处理网络异常、超时和数据损坏等情况，提高了系统的稳定性和可靠性。

### 2.2 ZKEMJavaPort-master库架构

ZKEMJavaPort-master采用了完全不同的技术路径，它基于COM4J技术来调用ZKTeco官方提供的zkemkeeper.dll动态链接库。这种方法的优势在于能够获得官方的完整功能支持和持续更新。

#### 2.2.1 COM4J集成架构

该库的核心是IZKEM接口，它通过COM4J技术映射了zkemkeeper.dll中的所有COM接口。COM4J是一个Java到COM的桥接技术，允许Java应用程序直接调用Windows COM组件。

**ClassFactory类**负责创建IZKEM接口的实例，它使用COM4J的createInstance方法来实例化底层的COM对象。这个过程涉及COM组件的注册、初始化和生命周期管理。

**IZKEM接口**定义了数百个方法，涵盖了考勤机的所有功能，包括连接管理、用户管理、考勤记录读取、设备配置、实时事件处理等。每个方法都有对应的DISPID和VTID标识，确保与COM接口的正确映射。

**AttendanceTerminal类**是一个高级封装类，它在IZKEM接口的基础上提供了更加面向对象和易于使用的API。该类实现了观察者模式，支持实时事件通知，并提供了完整的设备状态管理功能。

#### 2.2.2 事件处理机制

ZKEMJavaPort-master实现了完整的事件驱动架构，支持实时监听考勤机的各种事件，包括：

考勤事件（onAttTransactionEx）：当有员工打卡时触发，包含员工ID、验证方式、进出状态、时间戳等详细信息。

连接事件（onConnected/onDisConnected）：监控设备连接状态变化，支持自动重连和故障恢复。

注册事件（onEnrollFingerEx）：监听指纹注册过程，提供注册进度和结果反馈。

卡片事件（onHIDNum）：处理RFID卡片相关事件，支持卡片号码读取和验证。

## 3. 功能特性对比分析

### 3.1 连接管理功能

两个库在连接管理方面采用了不同的策略和实现方式，各有其特点和适用场景。

#### 3.1.1 ZKTeco4J-main连接管理

ZKTeco4J-main的连接管理相对简单直接，主要通过ZKTerminal类的connect()方法建立UDP连接。连接过程包括以下步骤：

首先创建DatagramSocket并解析目标IP地址，然后发送CMD_CONNECT命令到考勤机。设备响应后，提取sessionId用于后续通信。如果需要认证，可以调用connectAuth()方法使用通信密钥进行身份验证。

这种方式的优点是实现简单，不依赖外部库，连接建立速度快。缺点是需要手动管理连接状态，缺乏自动重连和错误恢复机制。

#### 3.1.2 ZKEMJavaPort-master连接管理

ZKEMJavaPort-master提供了更加完善的连接管理功能，通过AttendanceTerminal类实现了智能连接管理：

连接前会先进行网络ping测试，确保设备可达性。支持多种连接方式，包括网络连接（connect_Net）、串口连接（connect_Com）和USB连接（connect_USB）。

实现了完整的连接状态管理，包括DISCONNECTED、CONNECTING、NETWORK_PING、IDLE、READING、WRITING等多种状态。

提供了自动重连机制和错误恢复功能，能够自动处理网络中断、设备重启等异常情况。

支持连接池和并发连接管理，适合大规模部署和高并发场景。

### 3.2 数据读取功能

考勤记录的读取是考勤机集成的核心功能，两个库在这方面都提供了完整的解决方案，但实现方式和功能特性有所不同。

#### 3.2.1 考勤记录读取

ZKTeco4J-main通过getAttendanceRecords()方法读取考勤记录，该方法发送CMD_ATTLOG_RRQ命令并解析返回的二进制数据。数据解析过程包括：

从十六进制字符串中提取用户ID、验证方式、时间戳和操作类型等信息。时间戳采用特殊的编码格式，需要通过HexUtils.extractDate()方法进行解码。

支持大数据量的分包传输，当数据量超过单个UDP包的限制时，会自动处理多包数据的组装。

ZKEMJavaPort-master提供了更加灵活的考勤记录读取方式：

readAttendanceRecordsFrom()方法支持按时间范围读取记录，可以指定起始时间和结束时间。

readAttendanceRecordsForDay()方法专门用于读取指定日期的所有记录，自动处理时间范围计算。

readLastestLogData()方法支持增量读取，只获取指定时间点之后的新记录，提高了数据同步效率。

#### 3.2.2 用户信息管理

在用户信息管理方面，ZKEMJavaPort-master提供了更加完整的功能：

支持用户基本信息的增删改查，包括用户ID、姓名、密码、权限等。

提供了指纹模板的管理功能，支持多指纹注册、模板导入导出、指纹删除等操作。

支持RFID卡片管理，包括卡号绑定、卡片权限设置、卡片状态管理等。

实现了用户权限和时区管理，支持复杂的考勤规则配置。

ZKTeco4J-main在用户管理方面功能相对有限，主要专注于基础的数据读取功能，用户管理需要通过发送特定的命令来实现。

### 3.3 实时事件处理

实时事件处理是现代考勤系统的重要特性，能够实现即时的考勤监控和响应。

#### 3.3.1 ZKTeco4J-main事件处理

ZKTeco4J-main通过enableRealtime()方法注册事件监听，支持的事件类型由EventCode枚举定义。事件处理相对简单，主要通过轮询方式检查设备状态变化。

该库的事件处理机制较为基础，需要开发者自行实现事件分发和处理逻辑。适合对实时性要求不高的简单应用场景。

#### 3.3.2 ZKEMJavaPort-master事件处理

ZKEMJavaPort-master实现了完整的事件驱动架构，通过_IZKEMEvents接口定义了丰富的事件类型：

onAttTransactionEx事件提供了详细的考勤信息，包括员工ID、验证方式、进出状态、时间戳、工作代码等。

onEnrollFingerEx事件支持指纹注册过程的实时监控，提供注册进度和结果反馈。

onConnected和onDisConnected事件用于监控设备连接状态变化。

事件处理采用观察者模式，支持多个监听器同时注册，便于实现复杂的业务逻辑。

## 4. 技术依赖与兼容性分析

### 4.1 平台兼容性

两个库在平台兼容性方面存在显著差异，这直接影响了它们的适用场景和部署策略。

#### 4.1.1 ZKTeco4J-main平台支持

ZKTeco4J-main作为纯Java实现，具有优秀的跨平台特性：

支持所有主流操作系统，包括Windows、Linux、macOS、Unix等。

不依赖任何本地动态链接库，避免了平台相关的兼容性问题。

支持各种Java运行环境，包括Oracle JDK、OpenJDK、IBM JDK等。

适合云原生部署，支持容器化和微服务架构。

在嵌入式设备和ARM架构上也能正常运行，适合IoT和边缘计算场景。

#### 4.1.2 ZKEMJavaPort-master平台限制

ZKEMJavaPort-master由于依赖COM4J和zkemkeeper.dll，存在明显的平台限制：

仅支持Windows操作系统，无法在Linux或macOS上运行。

需要安装ZKTeco官方的SDK和驱动程序。

依赖Windows COM组件，需要进行COM组件注册。

在64位系统上可能需要特殊配置来支持32位COM组件。

不适合云原生部署和容器化环境。

### 4.2 依赖管理

#### 4.2.1 ZKTeco4J-main依赖

ZKTeco4J-main的依赖非常简洁，主要包括：

Apache Commons Lang3：用于字符串处理和工具函数。

标准Java库：网络通信、日期处理、集合操作等。

Maven构建支持，依赖管理简单明确。

总体依赖大小小于1MB，启动速度快，内存占用低。

#### 4.2.2 ZKEMJavaPort-master依赖

ZKEMJavaPort-master的依赖相对复杂：

COM4J库：提供Java到COM的桥接功能。

ICMP4J库：用于网络ping功能。

ZKTeco官方SDK：包含zkemkeeper.dll和相关组件。

Windows运行时库：支持COM组件运行。

总体依赖大小可能超过10MB，包含多个本地库文件。

## 5. 性能与稳定性分析

### 5.1 性能特征

#### 5.1.1 连接性能

ZKTeco4J-main在连接性能方面表现优异：

UDP连接建立速度快，通常在100-200毫秒内完成。

内存占用低，单个连接占用内存通常小于1MB。

支持高并发连接，理论上可以同时连接数百台设备。

网络开销小，协议效率高。

ZKEMJavaPort-master的连接性能相对较低：

COM组件初始化需要额外时间，连接建立可能需要500-1000毫秒。

内存占用较高，单个连接可能占用5-10MB内存。

并发连接能力有限，受COM组件线程模型限制。

但提供了更稳定的连接管理和自动重连功能。

#### 5.1.2 数据传输性能

在数据传输性能方面，两个库各有特点：

ZKTeco4J-main的数据传输效率较高，直接使用UDP协议，网络开销小。但需要手动处理大数据量的分包传输，实现复杂度较高。

ZKEMJavaPort-master通过官方SDK处理数据传输，自动处理分包和重传，但由于COM调用开销，整体性能略低。

### 5.2 稳定性评估

#### 5.2.1 错误处理能力

ZKTeco4J-main的错误处理相对简单：

提供基础的异常处理机制，主要是IOException和ParseException。

需要开发者自行实现重试逻辑和错误恢复。

网络异常处理需要额外的编程工作。

ZKEMJavaPort-master提供了更完善的错误处理：

内置自动重连机制，能够自动处理网络中断。

提供详细的错误代码和错误信息。

支持设备状态监控和异常恢复。

实现了完整的超时处理和资源清理。

#### 5.2.2 长期运行稳定性

在长期运行稳定性方面：

ZKTeco4J-main由于实现简单，长期运行稳定性较好，但需要注意内存泄漏和连接管理问题。

ZKEMJavaPort-master依赖COM组件，可能存在COM组件相关的稳定性问题，但官方SDK的成熟度较高。

## 6. 使用场景与选择建议

### 6.1 适用场景分析

#### 6.1.1 ZKTeco4J-main适用场景

ZKTeco4J-main特别适合以下场景：

**跨平台部署需求**：当应用需要在Linux服务器或云环境中运行时，ZKTeco4J-main是唯一选择。

**轻量级集成**：对于只需要基础考勤数据读取功能的简单应用，ZKTeco4J-main提供了最小化的解决方案。

**微服务架构**：在微服务和容器化环境中，ZKTeco4J-main的无依赖特性使其更容易部署和管理。

**高并发场景**：当需要同时连接大量考勤设备时，ZKTeco4J-main的高性能特性更有优势。

**嵌入式应用**：在资源受限的嵌入式设备上，ZKTeco4J-main的低内存占用是重要优势。

#### 6.1.2 ZKEMJavaPort-master适用场景

ZKEMJavaPort-master更适合以下场景：

**Windows桌面应用**：对于运行在Windows环境的桌面应用程序，ZKEMJavaPort-master提供了最完整的功能支持。

**复杂考勤管理系统**：当需要完整的用户管理、权限控制、实时监控等高级功能时，ZKEMJavaPort-master是更好的选择。

**企业级应用**：对于大型企业的考勤管理系统，ZKEMJavaPort-master的稳定性和功能完整性更重要。

**快速原型开发**：由于提供了高级API和丰富的功能，ZKEMJavaPort-master能够加快开发速度。

**官方支持需求**：当项目需要官方技术支持和持续更新时，基于官方SDK的ZKEMJavaPort-master更有保障。

### 6.2 选择决策框架

为了帮助开发者做出正确的选择，我们提供以下决策框架：

#### 6.2.1 技术因素考虑

**平台要求**：如果必须支持非Windows平台，选择ZKTeco4J-main。如果只在Windows环境运行，两者都可以考虑。

**功能需求**：如果只需要基础的考勤数据读取，ZKTeco4J-main足够。如果需要完整的设备管理功能，选择ZKEMJavaPort-master。

**性能要求**：对于高并发或低延迟要求，ZKTeco4J-main更合适。对于功能完整性要求更高的场景，选择ZKEMJavaPort-master。

**维护成本**：ZKTeco4J-main的维护成本较低，但功能扩展需要更多开发工作。ZKEMJavaPort-master功能丰富，但依赖管理复杂。

#### 6.2.2 业务因素考虑

**项目规模**：小型项目可以选择ZKTeco4J-main，大型企业项目建议选择ZKEMJavaPort-master。

**开发团队技能**：如果团队熟悉底层网络编程，ZKTeco4J-main是好选择。如果团队更擅长业务逻辑开发，ZKEMJavaPort-master更合适。

**时间预算**：紧急项目可以选择ZKEMJavaPort-master快速实现功能。有充足时间的项目可以考虑ZKTeco4J-main的定制化开发。

**长期规划**：如果计划长期维护和扩展，需要考虑库的活跃度和社区支持。




## 7. 连接测试方案与参数配置指导

成功连接考勤机是集成工作的第一步。本节将提供详细的连接测试方案，并指导如何配置连接参数，确保您的应用程序能够与考勤机正常通信。

### 7.1 连接测试方案

在实际部署之前，强烈建议您在开发环境中对考勤机连接进行充分测试。以下是验证代码能否成功连接考勤机的步骤和建议：

#### 7.1.1 前置条件

1.  **物理连接**：确保考勤机已正确连接到网络，并且与运行Java应用程序的计算机处于同一网络中（或可通过路由访问）。
2.  **IP地址和端口**：获取考勤机的正确IP地址和通信端口。通常，考勤机的默认通信端口是4370。这些信息通常可以在考勤机的系统设置中找到。
3.  **通信密码（可选）**：如果考勤机设置了通信密码，请确保您知道该密码。部分考勤机可能默认没有密码或密码为0。
4.  **防火墙设置**：确保计算机和考勤机之间的任何防火墙（包括操作系统防火墙和网络防火墙）都允许UDP（ZKTeco4J-main）或TCP（ZKEMJavaPort-master通过zkemkeeper.dll）流量通过考勤机端口。
5.  **Java开发环境**：确保您的开发环境已正确配置Java JDK，并且Maven或Gradle等构建工具已准备就绪。

#### 7.1.2 测试步骤

**步骤1：Ping测试**

在运行Java应用程序的计算机上，首先使用`ping`命令测试考勤机的IP地址，确保网络可达性。例如：

```bash
ping 192.168.1.201
```

如果ping不通，请检查网络连接、IP地址配置和防火墙设置。

**步骤2：端口扫描（可选）**

可以使用`nmap`或其他端口扫描工具，确认考勤机的通信端口是否开放。例如：

```bash
nmap -p 4370 192.168.1.201
```

如果端口未开放，可能需要检查考勤机设置或网络配置。

**步骤3：使用提供的库进行连接测试**

针对ZKTeco4J-main和ZKEMJavaPort-master，分别编写简单的测试代码来尝试连接考勤机并执行基本操作，例如获取设备时间或读取少量考勤记录。

**ZKTeco4J-main连接测试示例：**

```java
import ps.purelogic.zkteco4j.terminal.ZKTerminal;
import ps.purelogic.zkteco4j.commands.ZKCommandReply;
import ps.purelogic.zkteco4j.commands.GetTimeReply;

public class ZKTeco4JTest {
    public static void main(String[] args) {
        String ip = "192.168.1.201"; // 替换为您的考勤机IP地址
        int port = 4370; // 考勤机端口，通常是4370

        ZKTerminal terminal = new ZKTerminal(ip, port);

        try {
            System.out.println("尝试连接考勤机...");
            ZKCommandReply connectReply = terminal.connect();
            System.out.println("连接结果: " + connectReply.getReplyCode());

            if (connectReply.getReplyCode().isOk()) {
                System.out.println("连接成功！会话ID: " + connectReply.getSessionId());

                // 尝试获取设备时间
                System.out.println("尝试获取设备时间...");
                GetTimeReply timeReply = terminal.getDeviceTime();
                if (timeReply.getReplyCode().isOk()) {
                    System.out.println("设备时间: " + timeReply.getDeviceTime());
                } else {
                    System.out.println("获取设备时间失败: " + timeReply.getReplyCode());
                }

                // 断开连接
                System.out.println("断开连接...");
                terminal.disconnect();
                System.out.println("连接已断开。");
            } else {
                System.out.println("连接失败: " + connectReply.getReplyCode());
            }

        } catch (Exception e) {
            System.err.println("连接或操作过程中发生错误: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
```

**ZKEMJavaPort-master连接测试示例：**

```java
import com.fingerprints.ClassFactory;
import com.fingerprints.IZKEM;
import com4j.Holder;

public class ZKEMJavaPortTest {
    public static void main(String[] args) {
        String ip = "192.168.1.201"; // 替换为您的考勤机IP地址
        int port = 4370; // 考勤机端口，通常是4370
        int machineNumber = 1; // 考勤机机器号，通常是1
        int commKey = 0; // 通信密码，如果考勤机有设置，请替换

        IZKEM axCZKEM = ClassFactory.createCZKEM();

        try {
            System.out.println("尝试连接考勤机...");
            // 设置通信密码
            axCZKEM.setCommPassword(commKey);
            boolean connected = axCZKEM.connect_Net(ip, port);

            if (connected) {
                System.out.println("连接成功！");

                // 尝试获取设备时间
                Holder<Integer> year = new Holder<Integer>(0);
                Holder<Integer> month = new Holder<Integer>(0);
                Holder<Integer> day = new Holder<Integer>(0);
                Holder<Integer> hour = new Holder<Integer>(0);
                Holder<Integer> minute = new Holder<Integer>(0);
                Holder<Integer> second = new Holder<Integer>(0);

                System.out.println("尝试获取设备时间...");
                if (axCZKEM.getDeviceTime(machineNumber, year, month, day, hour, minute, second)) {
                    System.out.printf("设备时间: %d-%02d-%02d %02d:%02d:%02d\n",
                            year.value, month.value, day.value, hour.value, minute.value, second.value);
                } else {
                    Holder<Integer> errorCode = new Holder<Integer>(0);
                    axCZKEM.getLastError(errorCode);
                    System.out.println("获取设备时间失败，错误码: " + errorCode.value);
                }

                // 断开连接
                System.out.println("断开连接...");
                axCZKEM.disconnect();
                System.out.println("连接已断开。");
            } else {
                Holder<Integer> errorCode = new Holder<Integer>(0);
                axCZKEM.getLastError(errorCode);
                System.out.println("连接失败，错误码: " + errorCode.value);
            }

        } catch (Exception e) {
            System.err.println("连接或操作过程中发生错误: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
```

**步骤4：分析测试结果**

*   **成功连接**：如果测试代码输出“连接成功！”并能获取到设备时间，则表示连接正常。您可以进一步尝试读取考勤记录等操作。
*   **连接失败**：如果连接失败，请根据错误信息进行排查：
    *   **网络问题**：检查IP地址、端口、防火墙设置。
    *   **通信密码错误**：确保`commKey`参数正确。
    *   **设备未启用或繁忙**：尝试重启考勤机或检查其状态。
    *   **COM组件问题（仅限ZKEMJavaPort-master）**：确保zkemkeeper.dll已正确注册，并且Java应用程序有权限访问COM组件。

### 7.2 参数配置指导

考勤机连接通常需要配置以下几个关键参数：

1.  **考勤机IP地址**：这是考勤机在网络中的唯一标识。您需要在代码中将其设置为正确的IP地址。例如，在上述示例中，`String ip = "192.168.1.201";`。

2.  **考勤机端口**：考勤机用于通信的端口号。ZKTeco考勤机通常使用`4370`作为默认端口。请确保您的代码中使用的是正确的端口号。例如，`int port = 4370;`。

3.  **通信密码（Communication Key）**：部分考勤机可能设置了通信密码，用于验证连接的合法性。如果您的考勤机设置了密码，您需要在代码中提供正确的密码。在ZKTeco4J-main中，这通过`connectAuth(int comKey)`方法实现；在ZKEMJavaPort-master中，通过`axCZKEM.setCommPassword(commKey)`方法设置。如果考勤机没有设置密码，通常可以将其设置为`0`。

4.  **机器号（Machine Number）**：部分考勤机操作需要指定机器号，通常默认为`1`。在ZKEMJavaPort-master的许多方法中，都需要传入`dwMachineNumber`参数。例如，`axCZKEM.getDeviceTime(machineNumber, ...)`。

**修改参数的建议：**

*   **硬编码（不推荐）**：直接在代码中修改IP、端口和密码。这种方式简单，但不利于维护和部署。
*   **配置文件**：将这些参数存储在外部配置文件（如`properties`文件、`XML`文件或`JSON`文件）中。应用程序启动时读取这些配置，这样无需修改代码即可更改参数。
*   **命令行参数**：在启动Java应用程序时，通过命令行参数传入这些配置。例如：`java -jar your_app.jar --ip 192.168.1.201 --port 4370`。
*   **环境变量**：将参数设置为系统环境变量，应用程序从环境变量中读取。这在容器化部署中非常常见。

**示例：使用配置文件管理参数（以properties文件为例）**

创建一个`config.properties`文件：

```properties
zk.ip=192.168.1.201
zk.port=4370
zk.commKey=0
zk.machineNumber=1
```

在Java代码中读取：

```java
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class ConfigLoader {
    public static void main(String[] args) {
        Properties prop = new Properties();
        try (FileInputStream fis = new FileInputStream("config.properties")) {
            prop.load(fis);

            String ip = prop.getProperty("zk.ip");
            int port = Integer.parseInt(prop.getProperty("zk.port"));
            int commKey = Integer.parseInt(prop.getProperty("zk.commKey"));
            int machineNumber = Integer.parseInt(prop.getProperty("zk.machineNumber"));

            System.out.println("IP: " + ip);
            System.out.println("Port: " + port);
            System.out.println("Comm Key: " + commKey);
            System.out.println("Machine Number: " + machineNumber);

            // 在这里使用这些参数进行考勤机连接和操作

        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
}
```

通过以上测试方案和参数配置指导，您应该能够成功连接中控考勤机，并根据实际需求灵活调整连接参数。


