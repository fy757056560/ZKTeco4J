# ZKTeco4J-main 项目通信密码机制分析报告

**作者：** Manus AI  
**日期：** 2025年7月23日  
**版本：** 1.0

## 1. 引言

本报告旨在详细解释ZKTeco4J-main项目中通信密码（CommKey）的配置方式、其在与中控考勤机通信过程中如何被识别，以及涉及到的关键字段和算法。理解这一机制对于成功连接和控制带有通信密码的考勤机至关重要，尤其是在考勤机连接测试中遇到“卡住不动”等问题时，通信密码的正确配置往往是解决问题的关键。

## 2. 通信密码的配置与应用

在ZKTeco4J-main项目中，通信密码的配置和应用主要通过以下两个层面实现：

### 2.1 配置文件中的密码设置

为了避免硬编码，我们将考勤机的通信密码配置在 `config.properties` 文件中。在之前的交互中，我们已经将 `zk.commKey=202306` 添加到了该文件中。`Test.java` 文件负责读取这个配置项：

```java
int commKey = Integer.parseInt(prop.getProperty("zk.commKey", "0")); // 读取通信密码，如果不存在则默认为0
```

这行代码从 `config.properties` 中获取名为 `zk.commKey` 的属性值。如果该属性不存在，则默认使用 `0` 作为通信密码。这意味着，如果您的考勤机没有设置通信密码，或者密码为 `0`，则无需在配置文件中明确指定 `zk.commKey`。

### 2.2 `Test.java` 中的密码认证流程

`Test.java` 作为示例程序，在成功连接考勤机后，会调用 `ZKTerminal` 类的 `connectAuth(commKey)` 方法进行认证。这是将通信密码发送给考勤机的关键步骤：

```java
if (connectReply.getCode().isOk()) {
    System.out.println("连接成功！会话ID: " + connectReply.getSessionId());

    // 尝试认证，使用从配置文件读取的通信密码
    System.out.println("尝试使用通信密码 " + commKey + " 进行认证...");
    ZKCommandReply authReply = terminal.connectAuth(commKey);
    System.out.println("认证结果: " + authReply.getCode());

    if (authReply.getCode().isOk()) {
        System.out.println("认证成功！");
        // ... (后续操作)
    } else {
        System.out.println("认证失败: " + authReply.getCode());
    }
}
```

这里的 `terminal.connectAuth(commKey)` 方法是实际执行认证操作的地方。它将从配置文件中读取的 `commKey` 作为参数传递给考勤机。

## 3. 通信密码的识别机制

中控考勤机识别通信密码的机制涉及到ZKTeco私有协议中的认证命令和密钥生成算法。在ZKTeco4J-main项目中，这主要由 `ZKTerminal.java` 和 `SecurityUtils.java` 两个类协同完成。

### 3.1 `ZKTerminal.java` 中的认证命令发送

`ZKTerminal` 类中的 `connectAuth(int comKey)` 方法负责构建并发送认证命令（`CMD_AUTH`）到考勤机。其核心逻辑如下：

```java
public ZKCommandReply connectAuth(int comKey) throws IOException {
    int[] key = SecurityUtils.authKey(comKey, sessionId); // 1. 生成认证密钥

    int[] toSend = ZKCommand.getPacket(CommandCode.CMD_AUTH, sessionId, replyNo, key); // 2. 构建认证数据包
    byte[] buf = new byte[toSend.length];

    int index = 0;
    for (int byteToSend : toSend) {
        buf[index++] = (byte) byteToSend;
    }

    DatagramPacket packet = new DatagramPacket(buf, buf.length, address, port); // 3. 发送数据包
    socket.send(packet);

    replyNo++;

    int[] response = readResponse(); // 4. 读取考勤机响应

    CommandReplyCode replyCode = CommandReplyCode.decode(response[0] + (response[1] * 0x100));

    int replyId = response[6] + (response[7] * 0x100);

    int[] payloads = new int[response.length - 8];

    System.arraycopy(response, 8, payloads, 0, payloads.length);

    return new ZKCommandReply(replyCode, sessionId, replyId, payloads);
}
```

从代码中可以看出，`connectAuth` 方法并没有直接发送原始的 `comKey`。而是首先调用 `SecurityUtils.authKey(comKey, sessionId)` 方法来生成一个 `key` 数组，这个 `key` 数组才是实际作为数据载荷（payload）发送给考勤机进行认证的。这表明考勤机识别的不是原始密码，而是经过特定算法处理后的“认证密钥”。

### 3.2 `SecurityUtils.java` 中的密钥生成算法

`SecurityUtils` 类是处理ZKTeco协议中安全相关操作的核心。其中，`authKey` 和 `makeKey` 方法是生成认证密钥的关键：

#### 3.2.1 `makeKey(int key, int sessionId)` 方法

```java
public static long makeKey(int key, int sessionId) {
    int k;
    int i;

    short swp;

    k = 0;
    for (i = 0; i < 32; i++) {
        if ((key & (1 << i)) != 0) {
            k = (k << 1 | 1);
        } else {
            k = k << 1;
        }
    }

    k += sessionId;

    String hex = StringUtils.leftPad(Integer.toHexString(k), 8, "0");

    int[] response = new int[4];
    int index = 3;

    while (hex.length() > 0) {
        response[index] = (int) Long.parseLong(hex.substring(0, 2), 16);
        index--;

        hex = hex.substring(2);
    }

    response[0] ^= 'Z';
    response[1] ^= 'K';
    response[2] ^= 'S';
    response[3] ^= 'O';

    long finalKey = response[0] + (response[1] * 0x100) + (response[2] * 0x10000) + (response[3] * 0x1000000);

    swp = (short) (finalKey >> 16);
    finalKey = (finalKey << 16) + swp;

    return finalKey;
}
```

`makeKey` 方法接收原始的 `comKey`（即 `key` 参数）和当前的 `sessionId`。它执行了一系列位操作和异或运算来生成一个 `long` 类型的 `finalKey`。这个过程可以概括为：

1.  **位反转和累加：** 将原始 `key` 的每一位进行反转（如果为1则变为0，如果为0则变为1），并累加到 `k` 中。然后将 `sessionId` 加到 `k` 上。
2.  **字节重排和异或：** 将 `k` 转换为十六进制字符串，然后将其字节顺序反转并存储到 `response` 数组中。接着，对 `response` 数组的每个字节与特定的ASCII字符（'Z', 'K', 'S', 'O'）进行异或操作。
3.  **最终密钥生成：** 将处理后的 `response` 数组中的字节组合成一个 `long` 类型的 `finalKey`，并进行一次高低字节交换。

这个 `finalKey` 是 `authKey` 方法进一步处理的基础。

#### 3.2.2 `authKey(int comKey, int sessionId)` 方法

```java
public static int[] authKey(int comKey, int sessionId) {
    long k = Long.parseLong(Integer.toUnsignedString((int) makeKey(comKey, sessionId)));
    int rand = (int) (Math.random() * 255);

    int[] response = new int[4];
    int index = 3;

    String hex = StringUtils.leftPad(Long.toHexString(k), 8, "0");

    while (index >= 0) {
        response[index] = (int) Long.parseLong(hex.substring(0, 2), 16);
        index--;

        hex = hex.substring(2);
    }

    response[0] ^= rand;
    response[1] ^= rand;
    response[2] = rand;
    response[3] ^= rand;

    return response;
}
```

`authKey` 方法接收原始的 `comKey` 和 `sessionId`，并执行以下操作：

1.  **调用 `makeKey`：** 首先调用 `makeKey` 方法生成一个 `long` 类型的中间密钥 `k`。
2.  **生成随机数：** 生成一个 `0` 到 `255` 之间的随机数 `rand`。
3.  **字节处理和异或：** 将 `k` 转换为十六进制字符串，并将其字节顺序反转存储到 `response` 数组中。然后，对 `response` 数组的特定字节与随机数 `rand` 进行异或操作。
4.  **返回认证密钥：** 最终返回一个 `int[]` 数组，这个数组就是作为 `CMD_AUTH` 命令的数据载荷发送给考勤机的认证密钥。

**总结来说，考勤机识别通信密码的流程是：**

1.  应用程序将原始的通信密码（`comKey`）和当前会话ID发送给 `SecurityUtils.authKey` 方法。
2.  `authKey` 方法内部调用 `makeKey` 方法，对 `comKey` 和 `sessionId` 进行一系列复杂的位操作、异或运算和字节重排，生成一个中间密钥。
3.  `authKey` 方法再将这个中间密钥与一个随机数进行异或处理，最终生成一个4字节的认证密钥数组。
4.  这个4字节的认证密钥数组作为 `CMD_AUTH` 命令的数据载荷，通过UDP数据包发送给考勤机。
5.  考勤机接收到数据包后，会使用相同的算法对自身存储的通信密码和会话ID进行计算，并与接收到的认证密钥进行比对。如果匹配，则认证成功；否则，认证失败。

**关键字段：**

*   **`comKey` (通信密码)：** 这是您在考勤机上设置的原始密码，通常是一个数字。在代码中，它通过 `zk.commKey` 配置项读取。
*   **`sessionId` (会话ID)：** 这是在 `CMD_CONNECT` 命令成功后由考勤机返回的一个会话标识符。它在每次连接时都会变化，并且在认证密钥的生成中扮演重要角色，增加了通信的安全性。
*   **认证密钥数据载荷：** 这是一个4字节的数组，是经过 `makeKey` 和 `authKey` 算法处理后的最终结果，实际发送给考勤机进行认证。

## 4. 如何确定代码能成功连接考勤机

要确定代码能否成功连接考勤机，并正确处理通信密码，您需要关注以下几点：

1.  **网络连通性：** 这是最基础也是最重要的一步。如果网络不通，任何代码都无法连接。请确保您的考勤机已开机，并且与运行Java程序的计算机（沙盒环境）在同一个网络中，或者网络路由配置正确。使用 `ping` 命令测试考勤机IP地址的可达性是第一步。

    ```bash
ping 192.168.10.180
    ```

    如果 `ping` 命令失败，请检查网络线缆、路由器、IP地址配置、子网掩码、网关等。

2.  **防火墙设置：** ZKTeco4J-main使用UDP协议进行通信，默认端口是4370。请确保您的计算机和网络中的所有防火墙（包括操作系统防火墙、路由器防火墙、企业级防火墙等）都允许UDP流量通过4370端口。如果防火墙阻止了通信，即使代码逻辑正确，也无法建立连接。

3.  **考勤机通信密码：** 确保 `config.properties` 中配置的 `zk.commKey` 与您考勤机上设置的通信密码完全一致。即使是默认密码 `0`，也需要确保考勤机没有设置其他密码。

4.  **考勤机SDK通信模式：** 部分考勤机可能需要在设备上启用“SDK通信”或“网络通信”模式。请查阅您的中控U160考勤机说明书，确认是否有相关设置需要开启。

5.  **代码日志输出：** 观察 `Test.java` 程序的输出。如果程序能够成功连接，您会看到类似以下输出：

    ```
    尝试连接考勤机 192.168.10.180:4370...
    连接结果: CMD_ACK_OK
    连接成功！会话ID: XXXXX
    尝试使用通信密码 202306 进行认证...
    认证结果: CMD_ACK_OK
    认证成功！
    尝试获取设备时间...
    设备时间: YYYY-MM-DD HH:MM:SS
    启用设备结果: CMD_ACK_OK
    断开连接...
    连接已断开。
    ```

    如果 `连接结果` 或 `认证结果` 不是 `CMD_ACK_OK`，则表示连接或认证失败，需要根据返回的 `CommandReplyCode` 进行进一步排查。

    **常见的 `CommandReplyCode` 及其含义：**

    *   `CMD_ACK_OK`：操作成功。
    *   `CMD_ACK_ERROR`：操作失败，通常是由于命令错误或设备内部错误。
    *   `CMD_ACK_DATA_ERROR`：数据错误，可能发送的数据格式不正确。
    *   `CMD_ACK_UNAUTH`：未认证，通常是通信密码错误或未进行认证。
    *   `CMD_ACK_OLD_VERSION`：设备版本过旧，不支持某些命令。

    如果您在 `尝试连接考勤机...` 阶段就卡住不动，没有后续输出，这强烈表明是网络连通性问题，数据包根本没有到达考勤机，或者考勤机没有响应。

## 5. 总结

ZKTeco4J-main项目通过 `config.properties` 配置通信密码，并在 `Test.java` 中调用 `ZKTerminal.connectAuth()` 方法进行认证。认证过程中，原始通信密码会经过 `SecurityUtils` 类中的 `makeKey` 和 `authKey` 算法处理，生成一个4字节的认证密钥发送给考勤机。考勤机通过比对这个认证密钥来验证身份。

要确保代码能成功连接考勤机，最重要的是解决网络连通性问题和防火墙设置。在确认这些基础条件无误后，再检查通信密码是否正确配置，并观察程序的详细日志输出，根据 `CommandReplyCode` 来判断具体的问题所在。

## 6. 参考文献

*   [ZKTeco4J-main GitHub Repository](https://github.com/PureLogic/ZKTeco4J-main)
*   [ZKTeco Communication Protocol (Unofficial Documentation)](https://www.google.com/search?q=ZKTeco+communication+protocol)



