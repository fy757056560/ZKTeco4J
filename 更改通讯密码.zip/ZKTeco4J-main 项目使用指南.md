# ZKTeco4J-main 项目使用指南

**作者：** Manus AI  
**日期：** 2025年7月23日  
**版本：** 1.0

## 1. 引言

本指南旨在详细说明如何使用之前提供的修改后的 `ZKTeco4J-main_modified_source.zip` 源码压缩包和 `ZKTeco4J-1.0-SNAPSHOT.jar` 编译后的JAR文件。我们将分别介绍这两种文件的用途、如何部署和运行，并提供具体的步骤和示例，帮助您更好地利用这些代码连接和测试中控考勤机。

## 2. `ZKTeco4J-main_modified_source.zip` 源码压缩包的使用

`ZKTeco4J-main_modified_source.zip` 文件包含了我们之前对 `ZKTeco4J-main` 项目进行的所有修改，包括：

*   `config.properties` 文件：用于配置考勤机IP、端口和通信密码。
*   `src/main/java/ps/purelogic/zkteco4j/terminal/Test.java`：修改后的测试程序，能够读取配置文件并尝试连接和认证考勤机。
*   `src/main/java/ps/purelogic/zkteco4j/commands/CommandReplyCode.java`：添加了 `isOk()` 方法。
*   `src/main/java/ps/purelogic/zkteco4j/commands/GetTimeReply.java`：修正了方法名。
*   `src/main/java/ps/purelogic/zkteco4j/commands/ZKCommand.java`：修正了 `getPacket` 方法，使其返回完整的UDP数据包。
*   `src/test/java/ps/purelogic/zkteco4j/tests/ZKCommandTest.java`：修正了单元测试的预期值。

**使用场景：**

如果您希望：

*   查看所有修改的源代码。
*   在自己的开发环境中（例如Eclipse, IntelliJ IDEA）导入项目，进行二次开发或调试。
*   根据自己的需求修改代码逻辑，例如添加新的考勤机命令、处理更多数据类型等。
*   重新编译项目以生成新的JAR文件。

那么，您应该使用这个源码压缩包。

**使用步骤：**

1.  **解压文件：** 将 `ZKTeco4J-main_modified_source.zip` 解压到您希望存放项目的任意目录。例如，在Linux/macOS系统上，您可以使用 `unzip` 命令：

    ```bash
unzip ZKTeco4J-main_modified_source.zip
    ```

    解压后，您会得到一个名为 `ZKTeco4J-main` 的文件夹，其中包含了完整的项目结构。

2.  **导入到IDE（可选但推荐）：**

    *   **IntelliJ IDEA:** 打开IntelliJ IDEA，选择 `File -> Open`，然后导航到您解压后的 `ZKTeco4J-main` 文件夹并选择它。IDEA会自动识别这是一个Maven项目并导入。
    *   **Eclipse:** 选择 `File -> Import -> Maven -> Existing Maven Projects`，然后导航到您解压后的 `ZKTeco4J-main` 文件夹并选择它。

    导入后，IDE会自动下载Maven依赖并构建项目。

3.  **配置考勤机参数：**

    *   打开 `ZKTeco44J-main/config.properties` 文件。
    *   修改 `zk.ip` 为您的考勤机实际IP地址（例如：`192.168.10.180`）。
    *   修改 `zk.port` 为您的考勤机通信端口（通常是 `4370`）。
    *   如果您的考勤机设置了通信密码，请修改 `zk.commKey` 为您的密码（例如：`202306`）。如果考勤机没有密码，可以不设置或设置为 `0`。

    ```properties
    zk.ip=您的考勤机IP
    zk.port=您的考勤机端口
    zk.commKey=您的考勤机通信密码
    ```

4.  **编译项目（如果需要）：**

    如果您在IDE中导入了项目，通常IDE会自动进行编译。如果您在命令行中操作，或者需要强制重新编译，请确保您的系统已安装Maven，然后在 `ZKTeco4J-main` 目录下执行：

    ```bash
mvn clean install
    ```

    这将清理旧的编译文件，下载依赖，然后重新编译项目并生成新的JAR文件（位于 `target` 目录下）。

5.  **运行测试程序：**

    编译成功后，您可以在IDE中直接运行 `ps.purelogic.zkteco4j.terminal.Test` 类。如果是在命令行中运行，请确保您在 `ZKTeco4J-main` 目录下，并执行以下命令：

    ```bash
java -cp target/ZKTeco4J-1.0-SNAPSHOT.jar:target/dependency/* ps.purelogic.zkteco4j.terminal.Test
    ```

    **注意：** `target/dependency/*` 部分是为了确保所有Maven依赖的JAR包都能被Java虚拟机找到。在Windows系统上，路径分隔符是 `;` 而不是 `:`。

    ```bash
    # Windows 系统
java -cp target/ZKTeco44J-1.0-SNAPSHOT.jar;target/dependency/* ps.purelogic.zkteco4j.terminal.Test
    ```

    程序将尝试连接考勤机并输出连接和认证结果。请根据输出信息判断连接是否成功，并排查可能的问题（如网络不通、防火墙、密码错误等）。

## 3. `ZKTeco4J-1.0-SNAPSHOT.jar` 编译后JAR文件的使用

`ZKTeco4J-1.0-SNAPSHOT.jar` 文件是 `ZKTeco4J-main` 项目编译后的可执行JAR包。它包含了所有编译后的类文件，可以直接运行，无需再次编译源代码。

**使用场景：**

如果您希望：

*   快速部署和运行考勤机连接测试，无需搭建Java开发环境。
*   将考勤机连接功能集成到其他Java应用程序中（作为依赖库）。
*   在生产环境中部署一个简单的考勤机连接工具。

那么，您应该使用这个JAR文件。

**使用步骤：**

1.  **准备文件：**

    *   将 `ZKTeco4J-1.0-SNAPSHOT.jar` 文件复制到您希望运行它的目录。
    *   **重要：** 您还需要将 `config.properties` 文件（包含考勤机IP、端口和通信密码）放置在与 `ZKTeco4J-1.0-SNAPSHOT.jar` **相同的目录**下，或者确保 `Test.java` 中读取 `config.properties` 的路径是正确的。
    *   **依赖库：** `ZKTeco4J-main` 项目依赖了一些第三方库（例如 `commons-lang3`、`junit` 等）。在Maven编译时，这些依赖会被自动下载到本地Maven仓库。当您直接运行JAR文件时，需要确保这些依赖也能够被Java虚拟机找到。最简单的方法是，在您编译项目后，Maven会在 `target` 目录下生成一个 `dependency` 文件夹，里面包含了所有运行时需要的JAR包。您需要将这些依赖JAR包也复制到与 `ZKTeco4J-1.0-SNAPSHOT.jar` 相同的目录，或者在运行命令中指定它们的路径。

    为了方便，我们假设您已经将 `ZKTeco4J-1.0-SNAPSHOT.jar` 和 `config.properties` 以及 `target/dependency` 目录下的所有JAR文件都放在了同一个运行目录下。

2.  **配置考勤机参数：**

    *   打开与 `ZKTeco4J-1.0-SNAPSHOT.jar` 位于同一目录下的 `config.properties` 文件。
    *   修改 `zk.ip` 为您的考勤机实际IP地址。
    *   修改 `zk.port` 为您的考勤机通信端口。
    *   如果您的考勤机设置了通信密码，请修改 `zk.commKey` 为您的密码。

3.  **运行程序：**

    打开命令行终端，导航到您存放 `ZKTeco4J-1.0-SNAPSHOT.jar` 和 `config.properties` 的目录，然后执行以下命令：

    ```bash
java -cp ZKTeco4J-1.0-SNAPSHOT.jar:./dependency/* ps.purelogic.zkteco4j.terminal.Test
    ```

    **注意：**

    *   `./dependency/*` 表示当前目录下 `dependency` 文件夹中的所有JAR文件。请确保 `dependency` 文件夹存在且包含所有必要的依赖。
    *   在Windows系统上，路径分隔符是 `;` 而不是 `:`。

    ```bash
    # Windows 系统
java -cp ZKTeco4J-1.0-SNAPSHOT.jar;.\dependency\* ps.purelogic.zkteco4j.terminal.Test
    ```

    程序将尝试连接考勤机并输出连接和认证结果。请根据输出信息判断连接是否成功，并排查可能的问题。

## 4. 总结

无论是使用源码压缩包进行开发和调试，还是直接使用编译后的JAR文件进行部署和运行，关键都在于正确配置 `config.properties` 文件，并确保Java虚拟机能够找到所有必要的类和依赖库。在遇到连接问题时，请务必首先检查网络连通性、防火墙设置和考勤机本身的配置，因为这些往往是导致连接失败的主要原因。

希望这份指南能够帮助您顺利使用ZKTeco4J-main项目连接您的中控考勤机。如果您在操作过程中遇到任何问题，或者需要进一步的帮助，请随时提出。

## 5. 附件

*   `ZKTeco4J-main_modified_source.zip` (修改后的项目源码压缩包)
*   `ZKTeco4J-1.0-SNAPSHOT.jar` (编译后的JAR文件)

**重要提示：** 由于沙盒环境的限制，我无法直接将 `target/dependency` 目录下的所有依赖JAR文件打包发送给您。当您在本地编译项目后，请务必将 `target/dependency` 目录下的所有JAR文件与 `ZKTeco4J-1.0-SNAPSHOT.jar` 放在一起，或者在运行命令中正确指定它们的路径，否则程序将无法正常运行。

## 6. 参考文献

*   [Apache Maven Documentation](https://maven.apache.org/guides/)
*   [Java Command-Line Tools](https://docs.oracle.com/javase/8/docs/technotes/tools/windows/java.html)


