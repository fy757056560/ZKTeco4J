package com.zkteco;

import ps.purelogic.zkteco4j.terminal.ZKTerminal;
import ps.purelogic.zkteco4j.commands.ZKCommandReply;
import ps.purelogic.zkteco4j.commands.GetTimeReply;

public class SimpleTest {
    public static void main(String[] args) {
        System.out.println("开始测试中控考勤机连接...");
        
        // 使用您的考勤机IP地址
        String ip = "192.168.10.180";
        int port = 4370;
        
        ZKTerminal terminal = new ZKTerminal(ip, port);
        
        try {
            System.out.println("正在连接考勤机: " + ip + ":" + port);
            
            // 尝试连接
            ZKCommandReply connectReply = terminal.connect();
            System.out.println("连接响应代码: " + connectReply.getCode());
            
            if (connectReply.getCode().toString().contains("ACK_OK")) {
                System.out.println("✓ 连接成功！");
                
                // 测试获取设备时间
                try {
                    GetTimeReply timeReply = terminal.getDeviceTime();
                    System.out.println("✓ 获取设备时间成功，响应代码: " + timeReply.getCode());
                } catch (Exception e) {
                    System.out.println("× 获取设备时间失败: " + e.getMessage());
                }
                
                // 测试禁用设备
                try {
                    ZKCommandReply disableReply = terminal.disableDevice();
                    System.out.println("✓ 禁用设备成功，响应代码: " + disableReply.getCode());
                    
                    // 等待1秒后启用设备
                    Thread.sleep(1000);
                    ZKCommandReply enableReply = terminal.enableDevice();
                    System.out.println("✓ 启用设备成功，响应代码: " + enableReply.getCode());
                } catch (Exception e) {
                    System.out.println("× 设备控制失败: " + e.getMessage());
                }
                
                // 测试获取考勤记录
                try {
                    ZKCommandReply attendanceReply = terminal.getAttendanceRecords();
                    System.out.println("✓ 获取考勤记录成功，响应代码: " + attendanceReply.getCode());
                } catch (Exception e) {
                    System.out.println("× 获取考勤记录失败: " + e.getMessage());
                }
                
                // 断开连接
                terminal.disconnect();
                System.out.println("✓ 已断开连接");
                
            } else {
                System.out.println("× 连接失败，响应代码: " + connectReply.getCode());
            }
            
        } catch (Exception e) {
            System.out.println("× 连接过程中发生错误: " + e.getMessage());
            e.printStackTrace();
        }
        
        System.out.println("测试完成。");
    }
}

